import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'users-app',
    templateUrl: './usersapp.component.html'
  })
  export class UsersAppComponent {

  }  